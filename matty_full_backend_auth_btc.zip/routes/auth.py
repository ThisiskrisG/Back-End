from flask import Blueprint, request, jsonify, current_app, url_for
from flask_login import login_user, logout_user, current_user
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from app import db
from models import User

auth_bp = Blueprint("auth", __name__)

def _make_serializer():
    return URLSafeTimedSerializer(current_app.config["SECRET_KEY"], salt="matty-auth")

# ---------- Register (JSON) ----------
@auth_bp.route("/register", methods=["POST"])
def register():
    data = request.get_json() or {}
    username = data.get("username")
    email = data.get("email")
    password = data.get("password")

    if not username or not password:
        return jsonify({"error": "username and password required"}), 400

    if User.query.filter_by(username=username).first():
        return jsonify({"error": "Username already taken"}), 400

    if email and User.query.filter_by(email=email).first():
        return jsonify({"error": "Email already used"}), 400

    user = User(username=username, email=email or None, display_name=username)
    user.set_password(password)
    db.session.add(user)
    db.session.commit()

    # email verification token (printed to console)
    if user.email:
        s = _make_serializer()
        token = s.dumps({"user_id": user.id})
        verify_url = url_for("auth.verify_email", token=token, _external=True)
        current_app.logger.info("Verification link for %s: %s", user.email, verify_url)

    return jsonify({"success": True, "id": user.id, "username": user.username})

# ---------- Login (form-encoded for React) ----------
@auth_bp.route("/login", methods=["POST"])
def login():
    # React sends application/x-www-form-urlencoded
    username = request.form.get("username")
    password = request.form.get("password")

    if not username or not password:
        return jsonify({"error": "Missing credentials"}), 400

    user = User.query.filter_by(username=username).first()
    if not user or not user.check_password(password):
        return jsonify({"error": "Invalid credentials"}), 401

    login_user(user)
    return jsonify({
        "success": True,
        "id": user.id,
        "username": user.username,
        "email": user.email,
        "is_verified": user.is_verified,
    })

# ---------- Logout ----------
@auth_bp.route("/logout", methods=["GET"])
def logout():
    logout_user()
    return jsonify({"success": True})

# ---------- /api/me ----------
@auth_bp.route("/api/me")
def me():
    if not current_user.is_authenticated:
        return jsonify({"user": None}), 401

    return jsonify({
        "id": current_user.id,
        "username": current_user.username,
        "email": current_user.email,
        "is_verified": current_user.is_verified,
        "display_name": current_user.display_name,
        "bio": current_user.bio,
        "avatar_url": current_user.avatar_url,
    })

# ---------- Email verification ----------
@auth_bp.route("/verify/<token>")
def verify_email(token):
    s = _make_serializer()
    try:
        data = s.loads(token, max_age=60 * 60 * 24 * 3)  # 3 days
    except SignatureExpired:
        return jsonify({"error": "Token expired"}), 400
    except BadSignature:
        return jsonify({"error": "Invalid token"}), 400

    user = User.query.get(data.get("user_id"))
    if not user:
        return jsonify({"error": "User not found"}), 404

    user.is_verified = True
    db.session.commit()
    return jsonify({"success": True, "message": "Email verified"})

# ---------- Password reset: request & apply ----------
@auth_bp.route("/password/reset", methods=["POST"])
def request_password_reset():
    data = request.get_json() or {}
    email = data.get("email")
    if not email:
        return jsonify({"error": "email required"}), 400

    user = User.query.filter_by(email=email).first()
    if not user:
        # don't leak user existence
        return jsonify({"success": True})

    s = _make_serializer()
    token = s.dumps({"user_id": user.id})
    reset_url = url_for("auth.reset_with_token", token=token, _external=True)
    current_app.logger.info("Password reset link for %s: %s", user.email, reset_url)
    return jsonify({"success": True})

@auth_bp.route("/password/reset/<token>", methods=["POST"])
def reset_with_token(token):
    data = request.get_json() or {}
    password = data.get("password")
    if not password:
        return jsonify({"error": "password required"}), 400

    s = _make_serializer()
    try:
        data_token = s.loads(token, max_age=60 * 60 * 24)  # 1 day
    except SignatureExpired:
        return jsonify({"error": "Token expired"}), 400
    except BadSignature:
        return jsonify({"error": "Invalid token"}), 400

    user = User.query.get(data_token.get("user_id"))
    if not user:
        return jsonify({"error": "User not found"}), 404

    user.set_password(password)
    db.session.commit()
    return jsonify({"success": True})
