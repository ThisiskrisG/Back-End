import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, FlatList, ActivityIndicator } from 'react-native';
import CreatorCard from '../components/CreatorCard';
import { API_BASE } from '../api/config';

export default function CreatorsScreen({ navigation }) {
  const [creators, setCreators] = useState([]);
  const [loading, setLoading] = useState(true);

  async function loadCreators() {
    try {
      const res = await fetch(API_BASE + '/api/creators');
      const data = await res.json();
      setCreators(
        data.map(u => ({
          id: u.id,
          name: u.display_name || u.username,
          handle: '@' + u.username,
          tagline: u.bio || 'Creator on Matty',
          avatar: u.avatar_url || null,
          isVerified: u.is_verified,
        }))
      );
    } catch (e) {
      console.log('Creator fetch error', e);
    }
    setLoading(false);
  }

  useEffect(() => {
    loadCreators();
  }, []);

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator color="#f7931a" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Creators</Text>
      <FlatList
        data={creators}
        keyExtractor={item => item.id.toString()}
        renderItem={({ item }) => (
          <CreatorCard
            creator={item}
            onPress={() => navigation.navigate('Profile', { creator: item })}
          />
        )}
        contentContainerStyle={{ paddingVertical: 12 }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#050509',
    paddingHorizontal: 16,
    paddingTop: 20,
  },
  loadingContainer: {
    flex: 1,
    backgroundColor: '#050509',
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    color: '#fff',
    fontSize: 22,
    fontWeight: '600',
    marginBottom: 16,
  },
});
