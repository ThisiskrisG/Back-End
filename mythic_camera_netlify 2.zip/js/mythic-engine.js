// Mythic Engine – simplified preset + stubs so it runs without errors

let mythicMode = false;
let currentMode = "lite";

let lastLandmarks = null;
let lastPercent   = 50;
let lastVelocity  = 0;

let fusionDragon = null;

let holo, matrixFX, voidFX, hexFX, iceFX, triIceFX, frozenEntitiesFX;
let cryoFX, cryoBodyFX, frozenFaceFX, iceLightningFX, dualElemFX;
let twinSwordFX, dragonFX, fusionDragonFX, mythicCrownFX;
let rgbFX, liquidWarp, fractalFX, dropletFX;

const MODES = {
  lite: {
    mythic: false,
    effects: [
      "shockwave",
      "greenFire",
      "rgbSplit",
      "faceWrap",
      "liquidFace"
    ]
  },
  anime: {
    mythic: false,
    effects: [
      "shockwave",
      "greenFire",
      "rgbSplit",
      "faceWrap",
      "liquidFace",
      "matrix",
      "hologram"
    ]
  },
  mythic: {
    mythic: true,
    effects: [
      "hologram",
      "matrix",
      "void",
      "hex",
      "icePortal",
      "triIce",
      "frozenEntities",
      "cryoTornado",
      "cryoArmor",
      "frozenFace",
      "iceLightning",
      "dualElements",
      "twinSwords",
      "dragons",
      "fusionDragon",
      "mythicCrown",
      "rgbSplit",
      "liquidFace",
      "fractalLiquid",
      "droplets"
    ]
  }
};

function setupCanvas(id) {
  const canvas = document.getElementById(id);
  const ctx = canvas.getContext("2d");
  const resize = () => {
    canvas.width = canvas.clientWidth || window.innerWidth;
    canvas.height = canvas.clientHeight || window.innerHeight;
  };
  resize();
  window.addEventListener("resize", resize);
  return { canvas, ctx };
}

function initMythicCanvases() {
  holo             = setupCanvas("hologram-canvas");
  matrixFX         = setupCanvas("matrix-canvas");
  voidFX           = setupCanvas("voidwave-canvas");
  hexFX            = setupCanvas("hextech-canvas");
  iceFX            = setupCanvas("icetech-canvas");
  triIceFX         = setupCanvas("triice-canvas");
  frozenEntitiesFX = setupCanvas("frozenentities-canvas");
  cryoFX           = setupCanvas("cryovortex-canvas");
  cryoBodyFX       = setupCanvas("cryobody-canvas");
  frozenFaceFX     = setupCanvas("frozenface-canvas");
  iceLightningFX   = setupCanvas("icelightning-canvas");
  dualElemFX       = setupCanvas("dualelement-canvas");
  twinSwordFX      = setupCanvas("twinswords-canvas");
  dragonFX         = setupCanvas("dragons-canvas");
  fusionDragonFX   = setupCanvas("fusiondragon-canvas");
  mythicCrownFX    = setupCanvas("mythic-crown-canvas");
  rgbFX            = setupCanvas("rgbsplit-canvas");
  liquidWarp       = setupCanvas("liquid-canvas");
  fractalFX        = setupCanvas("fractal-canvas");
  dropletFX        = setupCanvas("droplet-canvas");
}

function initModeButtons() {
  const container = document.getElementById("mode-switcher");
  if (!container) return;
  const buttons = container.querySelectorAll("button");
  buttons.forEach(btn => {
    btn.addEventListener("click", () => {
      const mode = btn.getAttribute("data-mode");
      setMode(mode);
      buttons.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
    });
  });
  const defaultBtn = container.querySelector('button[data-mode="lite"]');
  if (defaultBtn) defaultBtn.classList.add("active");
}

function setMode(name) {
  if (!MODES[name]) return;
  currentMode = name;
  mythicMode  = MODES[name].mythic;
  const label = document.getElementById("mode-label");
  if (label) {
    label.textContent = "MODE: " + name.toUpperCase();
    label.classList.remove("mythic-glow", "mythic-shake");
  }
  console.log("Mode ->", name);
}

function mythicIngestInputs({ percent, velocity, landmarks }) {
  lastPercent  = percent;
  lastVelocity = velocity;
  if (landmarks) lastLandmarks = landmarks;
}

function mythicUpdateFrame() {
  const percent  = lastPercent;
  const velocity = lastVelocity;
  const lm       = lastLandmarks;
  const fx = MODES[currentMode].effects;

  if (fx.includes("hologram")) drawFractalHologram(percent);
  if (fx.includes("matrix"))   drawMatrixRain(percent);

  if (fx.includes("void"))           drawPurpleVoid(percent, velocity);
  if (fx.includes("hex"))            drawHexTechPortal(percent, velocity);
  if (fx.includes("icePortal"))      drawIceTechPortal(percent, velocity);
  if (fx.includes("triIce"))         drawTriIcePortal(percent, velocity);
  if (fx.includes("frozenEntities")) drawFrozenEntities(percent, velocity);
  if (fx.includes("cryoTornado"))    drawCryoTornado(percent, velocity);

  if (fx.includes("cryoArmor"))      drawCryoBodyArmor(lm);
  if (fx.includes("frozenFace"))     drawFrozenFace(lm);
  if (fx.includes("iceLightning"))   drawIceLightning(lm);
  if (fx.includes("dualElements"))   drawDualElements(lm);

  if (fx.includes("twinSwords"))     drawTwinElementSwords(lm);
  if (fx.includes("dragons"))        drawDragons(lm);
  if (fx.includes("fusionDragon"))   drawFusionDragon(lm);
  if (fx.includes("mythicCrown"))    drawMythicCrown(lm);

  if (fx.includes("shockwave"))      drawShockwavePulse(percent, velocity);
  if (fx.includes("greenFire"))      drawGreenFireAura(percent, velocity, lm);
  if (fx.includes("faceWrap"))       draw3DFaceWrap(percent, velocity, lm);
  if (fx.includes("liquidFace"))     draw3DLiquidFace(percent, velocity, lm);
  if (fx.includes("fractalLiquid"))  drawLiquidFractal(percent, velocity, lm);
  if (fx.includes("droplets"))       draw3DDropletDisplacement(percent, velocity, lm);
  if (fx.includes("rgbSplit"))       drawRGBSplit(percent, velocity);
}

// ---- SIMPLE STUB EFFECTS so it runs without your full code ----

function clearCanvas(ctx, w, h) {
  ctx.clearRect(0, 0, w, h);
}

function drawFractalHologram(p) {
  if (!holo) return;
  const { canvas, ctx } = holo;
  clearCanvas(ctx, canvas.width, canvas.height);
  ctx.globalAlpha = 0.25;
  ctx.strokeStyle = "rgba(0,255,200,0.4)";
  const spacing = 40;
  for (let x = 0; x < canvas.width; x += spacing) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, canvas.height);
    ctx.stroke();
  }
  for (let y = 0; y < canvas.height; y += spacing) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(canvas.width, y);
    ctx.stroke();
  }
  ctx.globalAlpha = 1;
}

function drawMatrixRain(p) {
  if (!matrixFX) return;
  const { canvas, ctx } = matrixFX;
  clearCanvas(ctx, canvas.width, canvas.height);
  ctx.globalAlpha = 0.2;
  ctx.fillStyle = "#0f0";
  const cols = 30;
  for (let i = 0; i < cols; i++) {
    const x = (i / cols) * canvas.width;
    const y = (Date.now() / 20 + i * 50) % canvas.height;
    ctx.fillText("|", x, y);
  }
  ctx.globalAlpha = 1;
}

// The rest are empty stubs – you can replace with your full implementations

function drawPurpleVoid() {}
function drawHexTechPortal() {}
function drawIceTechPortal() {}
function drawTriIcePortal() {}
function drawFrozenEntities() {}
function drawCryoTornado() {}
function drawCryoBodyArmor() {}
function drawFrozenFace() {}
function drawIceLightning() {}
function drawDualElements() {}
function drawTwinElementSwords() {}
function drawDragons() {}
function drawFusionDragon() {}
function drawMythicCrown() {}
function drawShockwavePulse() {}
function drawGreenFireAura() {}
function draw3DFaceWrap() {}
function draw3DLiquidFace() {}
function drawLiquidFractal() {}
function draw3DDropletDisplacement() {}
function drawRGBSplit() {}

// trigger stubs
function triggerFusionDragon() {}
function triggerIceBurst() {}
function triggerTriIcePortal() {}
function triggerFrozenEntities() {}
function triggerCryoVortex() {}
function triggerShockwave() {}
function triggerVoidWave() {}
function triggerHexBurst() {}
