const video = document.getElementById("video");
let running = false;

// Real FaceMesh landmarks will land here
let currentLandmarks = null;

// Slider values
let sliderPercent = 50;
let sliderVelocity = 0;
const faceTarget = 50; // center

let lastSliderValue = sliderPercent;
let lastSliderTime = performance.now();
let ultimateTimeout = null;

async function startCamera() {
  const stream = await navigator.mediaDevices.getUserMedia({
    video: { facingMode: "user" },
    audio: false
  });
  video.srcObject = stream;
  await video.play();
}

function onFaceResults(results) {
  if (results.multiFaceLandmarks && results.multiFaceLandmarks.length > 0) {
    currentLandmarks = results.multiFaceLandmarks[0];
  } else {
    currentLandmarks = null;
  }
}

async function initFaceMesh() {
  const faceMesh = new FaceMesh.FaceMesh({
    locateFile: (file) =>
      `https://cdn.jsdelivr.net/npm/@mediapipe/facemesh/${file}`,
  });

  faceMesh.setOptions({
    maxNumFaces: 1,
    refineLandmarks: true,
    minDetectionConfidence: 0.5,
    minTrackingConfidence: 0.5,
  });

  faceMesh.onResults(onFaceResults);

  const camera = new Camera.Camera(video, {
    onFrame: async () => {
      await faceMesh.send({ image: video });
    },
    width: 640,
    height: 480,
  });

  camera.start();
}

function initSlider() {
  const slider = document.getElementById("intensity-slider");
  const label  = document.getElementById("slider-label");
  const modeLabel = document.getElementById("mode-label");
  const ultimateLabel = document.getElementById("ultimate-label");
  if (!slider) return;

  slider.addEventListener("input", () => {
    const now = performance.now();
    const newVal = Number(slider.value);

    const dt = (now - lastSliderTime) || 16;
    const dv = newVal - lastSliderValue;

    sliderPercent = newVal;
    sliderVelocity = (dv / dt) * 16;

    // Slider label text & color bands
    label.textContent = `INTENSITY: ${newVal}%`;
    label.classList.remove("low", "mid", "high", "max", "animate", "shake");

    if (newVal < 30)       label.classList.add("low");
    else if (newVal < 70)  label.classList.add("mid");
    else if (newVal < 90)  label.classList.add("high");
    else                   label.classList.add("max");

    void label.offsetWidth;
    label.classList.add("animate");
    if (newVal >= 70) label.classList.add("shake");

    // Mode label glow/shake in mythic
    if (modeLabel) {
      modeLabel.classList.remove("mythic-glow", "mythic-shake");

      if (currentMode === "mythic") {
        if (newVal >= 40) modeLabel.classList.add("mythic-glow");
        if (newVal >= 80) {
          void modeLabel.offsetWidth;
          modeLabel.classList.add("mythic-shake");
        }
      }
    }

    // Ultimate ready indicator + shake/flash + fusion
    if (ultimateLabel) {
      const speed = Math.abs(sliderVelocity);
      const appEl   = document.getElementById("app");
      const flashEl = document.getElementById("ultimate-flash");

      if (currentMode === "mythic" && newVal >= 90 && speed > 0.6) {
        ultimateLabel.classList.add("show");
        ultimateLabel.classList.remove("flash");
        void ultimateLabel.offsetWidth;
        ultimateLabel.classList.add("flash");

        if (ultimateTimeout) clearTimeout(ultimateTimeout);
        ultimateTimeout = setTimeout(() => {
          ultimateLabel.classList.remove("show");
        }, 1500);

        if (typeof triggerFusionDragon === "function") {
          triggerFusionDragon();
        }

        if (appEl) {
          appEl.classList.remove("screen-shake");
          void appEl.offsetWidth;
          appEl.classList.add("screen-shake");
        }

        if (flashEl) {
          flashEl.classList.remove("flash-on");
          void flashEl.offsetWidth;
          flashEl.classList.add("flash-on");
        }
      }
    }

    lastSliderValue = newVal;
    lastSliderTime = now;
  });
}

window.addEventListener("load", async () => {
  initMythicCanvases();
  initModeButtons();
  setMode("lite");

  await startCamera();
  await initFaceMesh();

  initSlider();

  running = true;
  requestAnimationFrame(loop);
});

function loop() {
  if (!running) {
    requestAnimationFrame(loop);
    return;
  }

  mythicIngestInputs({
    percent: sliderPercent,
    velocity: sliderVelocity,
    landmarks: currentLandmarks
  });

  mythicUpdateFrame();
  requestAnimationFrame(loop);
}
