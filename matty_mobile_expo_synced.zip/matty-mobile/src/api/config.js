// Point this to your Matty backend (Flask on Render, etc.)
export const API_BASE = process.env.EXPO_PUBLIC_API_BASE || 'http://10.0.2.2:5000';
// 10.0.2.2 is Android emulator -> localhost
