from flask import Blueprint, jsonify, request
from models import User, Tip
from app import db

profile_bp = Blueprint("profile", __name__)

@profile_bp.route("/profile/<int:user_id>")
def profile_page(user_id):
    user = User.query.get_or_404(user_id)
    # This is JSON for now; you can swap to render_template if desired
    return jsonify({
        "id": user.id,
        "username": user.username,
        "display_name": user.display_name or user.username,
        "bio": user.bio,
        "avatar_url": user.avatar_url,
        "is_verified": user.is_verified,
    })

@profile_bp.route("/profile/<int:user_id>/earnings")
def earnings(user_id):
    tips = Tip.query.filter_by(user_id=user_id, status="completed").all()
    total = sum(t.amount for t in tips)
    return jsonify({
        "user_id": user_id,
        "total": round(total, 2),
        "currency": "USD",
        "tips": [{
            "id": t.id,
            "amount": t.amount,
            "currency": t.currency,
            "status": t.status,
            "created_at": t.created_at.isoformat(),
        } for t in tips]
    })

# ----- BTC Tip Creation Stub (Coinbase/Stripe gateway goes here) -----
@profile_bp.route("/btc/create", methods=["POST"])
def btc_create():
    data = request.get_json() or {}
    amount = data.get("amount")
    creator_id = data.get("creator_id")

    if not amount or not creator_id:
        return jsonify({"error": "amount and creator_id required"}), 400

    # TODO: Integrate Coinbase Commerce / Stripe / BTCPay here.
    # For now we return a placeholder checkout URL.
    pseudo_charge_id = f"MATTY_{creator_id}_{amount}".replace(".", "_")
    checkout_url = f"https://commerce.coinbase.com/charges/{pseudo_charge_id}"

    # Record pending tip
    tip = Tip(user_id=creator_id, amount=float(amount), status="pending")
    db.session.add(tip)
    db.session.commit()

    return jsonify({"url": checkout_url})
