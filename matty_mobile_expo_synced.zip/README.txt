# Matty Mobile (Expo, synced with backend creators)

This project is a mobile Matty app with:

- Home screen
- Creators list **synced from your backend** at GET /api/creators
- Profile screen per creator with BTC tip sheet (POST /btc/create)
- Login / Register (talks to /login, /register, /api/me)
- Dashboard showing logged-in user + backend URL

## 1. Install dependencies

```bash
cd matty-mobile
npm install
```

## 2. Point to your backend

Edit `src/api/config.js` or set env var:

```js
export const API_BASE = process.env.EXPO_PUBLIC_API_BASE || 'http://10.0.2.2:5000';
```

For local Android emulator with backend on your machine:

- Run backend on `http://localhost:5000`
- Keep `10.0.2.2:5000` (emulator -> host)

For a Render URL (example):

```bash
EXPO_PUBLIC_API_BASE="https://matty-backend.onrender.com" npx expo start
```

## 3. Run the app

```bash
npx expo start
```

- Scan QR with Expo Go on your phone, or
- Use an Android/iOS simulator

Creators list will hit:

- `GET {API_BASE}/api/creators`

BTC tipping uses:

- `POST {API_BASE}/btc/create` with `{ amount, creator_id }`
