from flask import Blueprint, jsonify
from models import User

creators_bp = Blueprint("creators", __name__)

@creators_bp.route("/api/creators")
def list_creators():
    users = User.query.limit(50).all()
    return jsonify([{
        "id": u.id,
        "username": u.username,
        "display_name": u.display_name or u.username,
        "bio": u.bio,
        "avatar_url": u.avatar_url,
        "is_verified": u.is_verified,
    } for u in users])
