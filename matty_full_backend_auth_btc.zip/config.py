import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "replace-me-in-production")
    SQLALCHEMY_DATABASE_URI = os.environ.get("DATABASE_URL") or "sqlite:///" + os.path.join(BASE_DIR, "matty.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Frontend origins allowed to talk to this backend
    CORS_ORIGINS = os.environ.get("CORS_ORIGINS", "http://localhost:5173,https://matty.xyz,https://*.netlify.app")
